// ═══════════════════════════════════════════════════════════════════
// PassKey Vault — Frontend Application
// ═══════════════════════════════════════════════════════════════════
const { startRegistration, startAuthentication, browserSupportsWebAuthn } = SimpleWebAuthnBrowser;

// ─── Particles Background ───────────────────────────────────────
(function initParticles() {
  const container = document.getElementById('particles');
  for (let i = 0; i < 30; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    const size = Math.random() * 4 + 2;
    p.style.width = size + 'px';
    p.style.height = size + 'px';
    p.style.left = Math.random() * 100 + '%';
    p.style.animationDuration = (Math.random() * 15 + 10) + 's';
    p.style.animationDelay = (Math.random() * 10) + 's';
    container.appendChild(p);
  }
})();

// ─── Utility Functions ──────────────────────────────────────────
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

function showLoading(text = 'Processing...') {
  document.getElementById('loading-text').textContent = text;
  document.getElementById('loading-overlay').classList.remove('hidden');
}

function hideLoading() {
  document.getElementById('loading-overlay').classList.add('hidden');
}

function showMessage(text, type = 'error') {
  const el = document.getElementById('auth-message');
  el.textContent = text;
  el.className = `message ${type}`;
}

function hideMessage() {
  document.getElementById('auth-message').className = 'message hidden';
}

function toast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  container.appendChild(el);
  setTimeout(() => { el.classList.add('removing'); setTimeout(() => el.remove(), 300); }, 4000);
}

// Button ripple effect
document.addEventListener('mousemove', (e) => {
  document.querySelectorAll('.btn').forEach(btn => {
    const rect = btn.getBoundingClientRect();
    btn.style.setProperty('--x', ((e.clientX - rect.left) / rect.width * 100) + '%');
    btn.style.setProperty('--y', ((e.clientY - rect.top) / rect.height * 100) + '%');
  });
});

// ─── Tab Switching ──────────────────────────────────────────────
function switchTab(tab) {
  hideMessage();
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
  
  const indicator = document.getElementById('tab-indicator');
  if (tab === 'login') {
    document.getElementById('tab-login').classList.add('active');
    document.getElementById('login-form').classList.add('active');
    indicator.classList.remove('right');
  } else {
    document.getElementById('tab-register').classList.add('active');
    document.getElementById('register-form').classList.add('active');
    indicator.classList.add('right');
  }
}

// ─── WebAuthn Support Check ────────────────────────────────────
if (!browserSupportsWebAuthn()) {
  document.querySelectorAll('.btn-primary, .btn-secondary').forEach(btn => btn.disabled = true);
  showMessage('Your browser does not support WebAuthn/Passkeys. Please use a modern browser.', 'error');
}

// ─── Registration ───────────────────────────────────────────────
async function handleRegister() {
  hideMessage();
  const username = document.getElementById('reg-username').value.trim();
  const displayName = document.getElementById('reg-displayname').value.trim();

  if (!username || username.length < 3) {
    showMessage('Username must be at least 3 characters', 'error');
    return;
  }
  if (!/^[a-zA-Z0-9_.\-]+$/.test(username)) {
    showMessage('Username can only contain letters, numbers, dots, dashes, underscores', 'error');
    return;
  }

  try {
    showLoading('Generating passkey options...');

    const optResp = await fetch('/api/register/options', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, displayName: displayName || username }),
    });
    const optionsJSON = await optResp.json();
    if (!optResp.ok) { hideLoading(); showMessage(optionsJSON.error, 'error'); return; }

    hideLoading();
    showLoading('Waiting for your passkey...');

    let attResp;
    try {
      attResp = await startRegistration({ optionsJSON });
    } catch (error) {
      hideLoading();
      if (error.name === 'InvalidStateError') {
        showMessage('This authenticator is already registered.', 'error');
      } else if (error.name === 'NotAllowedError') {
        showMessage('Passkey creation was cancelled or timed out.', 'warning');
      } else {
        showMessage('Error: ' + error.message, 'error');
      }
      return;
    }

    showLoading('Verifying registration...');
    const verifyResp = await fetch('/api/register/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(attResp),
    });
    const verifyJSON = await verifyResp.json();
    hideLoading();

    if (verifyJSON.verified) {
      toast('Account created successfully! 🎉', 'success');
      loadDashboard();
    } else {
      showMessage(verifyJSON.error || 'Registration failed', 'error');
    }
  } catch (err) {
    hideLoading();
    showMessage('Network error. Please try again.', 'error');
    console.error(err);
  }
}

// ─── Login (with username) ──────────────────────────────────────
async function handleLogin() {
  hideMessage();
  const username = document.getElementById('login-username').value.trim();
  if (!username) { showMessage('Please enter your username', 'error'); return; }

  try {
    showLoading('Generating authentication challenge...');
    const optResp = await fetch('/api/login/options', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username }),
    });
    const optionsJSON = await optResp.json();
    if (!optResp.ok) { hideLoading(); showMessage(optionsJSON.error, 'error'); return; }

    hideLoading();
    showLoading('Waiting for your passkey...');

    let asseResp;
    try {
      asseResp = await startAuthentication({ optionsJSON });
    } catch (error) {
      hideLoading();
      if (error.name === 'NotAllowedError') {
        showMessage('Authentication was cancelled or timed out.', 'warning');
      } else {
        showMessage('Error: ' + error.message, 'error');
      }
      return;
    }

    showLoading('Verifying...');
    const verifyResp = await fetch('/api/login/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(asseResp),
    });
    const verifyJSON = await verifyResp.json();
    hideLoading();

    if (verifyJSON.verified) {
      if (verifyJSON.previousSessionsTerminated > 0) {
        toast(`⚠️ ${verifyJSON.previousSessionsTerminated} other session(s) were terminated`, 'warning');
      }
      toast('Signed in successfully! 🔓', 'success');
      loadDashboard();
    } else {
      showMessage(verifyJSON.error || 'Authentication failed', 'error');
    }
  } catch (err) {
    hideLoading();
    showMessage('Network error. Please try again.', 'error');
    console.error(err);
  }
}

// ─── Discoverable Login (no username) ───────────────────────────
async function handleDiscoverableLogin() {
  hideMessage();
  try {
    showLoading('Preparing passkey authentication...');
    const optResp = await fetch('/api/login/options-discoverable');
    const optionsJSON = await optResp.json();
    if (!optResp.ok) { hideLoading(); showMessage(optionsJSON.error, 'error'); return; }

    hideLoading();
    showLoading('Select a passkey...');

    let asseResp;
    try {
      asseResp = await startAuthentication({ optionsJSON });
    } catch (error) {
      hideLoading();
      if (error.name === 'NotAllowedError') {
        showMessage('Authentication was cancelled or timed out.', 'warning');
      } else {
        showMessage('Error: ' + error.message, 'error');
      }
      return;
    }

    showLoading('Verifying...');
    const verifyResp = await fetch('/api/login/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(asseResp),
    });
    const verifyJSON = await verifyResp.json();
    hideLoading();

    if (verifyJSON.verified) {
      if (verifyJSON.previousSessionsTerminated > 0) {
        toast(`⚠️ ${verifyJSON.previousSessionsTerminated} other session(s) were terminated`, 'warning');
      }
      toast('Signed in successfully! 🔓', 'success');
      loadDashboard();
    } else {
      showMessage(verifyJSON.error || 'Authentication failed', 'error');
    }
  } catch (err) {
    hideLoading();
    showMessage('Network error. Please try again.', 'error');
    console.error(err);
  }
}

// ─── Dashboard ──────────────────────────────────────────────────
async function loadDashboard() {
  showScreen('dashboard-screen');
  try {
    const resp = await fetch('/api/me');
    if (!resp.ok) { showScreen('auth-screen'); toast('Session expired', 'error'); return; }
    const data = await resp.json();

    document.getElementById('welcome-name').textContent = data.displayName || data.username;
    document.getElementById('header-username').textContent = data.username;
    document.getElementById('user-avatar').textContent = (data.username[0] || 'U').toUpperCase();
    document.getElementById('stat-passkeys').textContent = data.passkeys.length;
    document.getElementById('stat-sessions').textContent = data.activeSessions.length;
    document.getElementById('stat-created').textContent = new Date(data.createdAt + 'Z').toLocaleDateString();

    renderPasskeys(data.passkeys);
    renderSessions(data.activeSessions);
  } catch (err) {
    console.error(err);
    toast('Failed to load dashboard', 'error');
  }
}

function renderPasskeys(passkeys) {
  const container = document.getElementById('passkeys-list');
  if (passkeys.length === 0) {
    container.innerHTML = '<div class="empty-state">No passkeys registered yet.</div>';
    return;
  }
  container.innerHTML = passkeys.map(pk => {
    const transportText = (pk.transports || []).join(', ') || 'Unknown';
    const typeLabel = pk.deviceType === 'multiDevice' ? 'Multi-Device' : 'Single-Device';
    const typeBadge = pk.deviceType === 'multiDevice' ? 'badge-primary' : 'badge-warning';
    const date = new Date(pk.createdAt + 'Z').toLocaleDateString();
    return `
      <div class="passkey-item">
        <div class="item-info">
          <div class="item-icon passkey">🔑</div>
          <div class="item-details">
            <h4>Passkey • ${transportText}</h4>
            <p>Created ${date} ${pk.backedUp ? '• ☁️ Backed up' : ''}</p>
          </div>
          <span class="badge ${typeBadge}">${typeLabel}</span>
        </div>
        <button class="btn btn-danger btn-sm" onclick="handleRemovePasskey('${pk.id}')">Remove</button>
      </div>`;
  }).join('');
}

function renderSessions(sessions) {
  const container = document.getElementById('sessions-list');
  if (sessions.length === 0) {
    container.innerHTML = '<div class="empty-state">No active sessions.</div>';
    return;
  }
  container.innerHTML = sessions.map(s => {
    const lastActive = new Date(s.lastActive + 'Z').toLocaleString();
    const ua = parseUserAgent(s.userAgent);
    return `
      <div class="session-item">
        <div class="item-info">
          <div class="item-icon session">${s.isCurrent ? '🟢' : '🔵'}</div>
          <div class="item-details">
            <h4>${ua} ${s.isCurrent ? '<span class="badge badge-success">Current</span>' : ''}</h4>
            <p>IP: ${s.ipAddress || 'Unknown'} • Last active: ${lastActive}</p>
          </div>
        </div>
        ${!s.isCurrent ? `<button class="btn btn-danger btn-sm" onclick="handleTerminateSession('${s.id}')">Terminate</button>` : ''}
      </div>`;
  }).join('');
}

function parseUserAgent(ua) {
  if (!ua) return 'Unknown Device';
  if (ua.includes('Chrome')) return '🌐 Chrome';
  if (ua.includes('Firefox')) return '🦊 Firefox';
  if (ua.includes('Safari')) return '🧭 Safari';
  if (ua.includes('Edge')) return '🌊 Edge';
  return '🌐 Browser';
}

// ─── Passkey Management ─────────────────────────────────────────
async function handleAddPasskey() {
  try {
    showLoading('Generating options...');
    const optResp = await fetch('/api/passkeys/add/options', { method: 'POST' });
    const optionsJSON = await optResp.json();
    if (!optResp.ok) { hideLoading(); toast(optionsJSON.error, 'error'); return; }

    hideLoading();
    showLoading('Register your new passkey...');
    let attResp;
    try { attResp = await startRegistration({ optionsJSON }); }
    catch (e) { hideLoading(); toast('Passkey creation cancelled', 'warning'); return; }

    showLoading('Verifying...');
    const verifyResp = await fetch('/api/passkeys/add/verify', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(attResp),
    });
    const result = await verifyResp.json();
    hideLoading();

    if (result.verified) { toast('New passkey added! 🔑', 'success'); loadDashboard(); }
    else { toast('Failed to add passkey', 'error'); }
  } catch (err) { hideLoading(); toast('Error adding passkey', 'error'); console.error(err); }
}

async function handleRemovePasskey(credentialId) {
  if (!confirm('Remove this passkey? You won\'t be able to sign in with it anymore.')) return;
  try {
    const resp = await fetch(`/api/passkeys/${encodeURIComponent(credentialId)}`, { method: 'DELETE' });
    const result = await resp.json();
    if (resp.ok) { toast('Passkey removed', 'success'); loadDashboard(); }
    else { toast(result.error, 'error'); }
  } catch (err) { toast('Error removing passkey', 'error'); }
}

// ─── Session Management ─────────────────────────────────────────
async function handleTerminateSession(sessionId) {
  try {
    const resp = await fetch(`/api/sessions/${sessionId}/terminate`, { method: 'POST' });
    if (resp.ok) { toast('Session terminated', 'success'); loadDashboard(); }
    else { const r = await resp.json(); toast(r.error, 'error'); }
  } catch (err) { toast('Error terminating session', 'error'); }
}

async function handleTerminateOtherSessions() {
  try {
    const resp = await fetch('/api/sessions/terminate-others', { method: 'POST' });
    const result = await resp.json();
    if (resp.ok) { toast(`${result.terminatedCount} session(s) terminated`, 'success'); loadDashboard(); }
    else { toast(result.error, 'error'); }
  } catch (err) { toast('Error', 'error'); }
}

async function handleLogout() {
  try {
    await fetch('/api/logout', { method: 'POST' });
    toast('Logged out', 'info');
    showScreen('auth-screen');
  } catch (err) { toast('Error logging out', 'error'); }
}

// ─── Check Auth on Load ────────────────────────────────────────
(async function checkAuth() {
  try {
    const resp = await fetch('/api/auth-status');
    const data = await resp.json();
    if (data.authenticated) { loadDashboard(); }
  } catch (err) { /* not authenticated */ }
})();

// Enter key support
document.getElementById('login-username').addEventListener('keydown', e => { if (e.key === 'Enter') handleLogin(); });
document.getElementById('reg-username').addEventListener('keydown', e => { if (e.key === 'Enter') handleRegister(); });
